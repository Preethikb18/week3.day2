package week3.day2;

public interface AndroidTVDesign {
	
	
	public void prize();
	public void musicPlay();
	public void gamePlay();
	

}
