package week3.day2;

public class SmartPhone extends AndroidPhone{
	
	public void takeVideo()
	{
		System.out.println("Smart phone take video");
	}

	public static void main(String[] args) {
		
		SmartPhone  objSmart =new SmartPhone();
		objSmart.sendMsg();
		objSmart.makeCall();
		objSmart.saveContact();
		objSmart.takeVideo();
		
		
		
		
	}

}
