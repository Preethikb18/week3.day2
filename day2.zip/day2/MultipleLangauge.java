package week3.day2;

public abstract class MultipleLangauge {
	
	public void python()
	{
		System.out.println("Python language of  MultipleLangauge");
	}
	
	public abstract void ruby();
	

	
}
