package week3.day2;

public abstract class SamsungTV  implements AndroidTVDesign{

	public  void googleCast()
	{
		System.out.println("Google cast");
	}
	public void prize()
	{
		System.out.println("52000");
	}
	
	public void musicPlay()
	{
		System.out.println("Music plays");
	}
	
	public void gamePlay()
	{
		System.out.println("game plays");
	}
	
	
	
}
