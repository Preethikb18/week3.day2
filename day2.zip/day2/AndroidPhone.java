package week3.day2;


public class AndroidPhone extends Mobile{
	
	public void makeCall()
	{
		
		System.out.println("Android phone make call");
	}

	public void saveContact()
	{
		
		System.out.println("Android phone Save the contact");
	}
	public void sendMsg()
	{
		
		System.out.println("Android phone Send Message");
	}
	
	public void takeVideo()
	{
		System.out.println("Android phone take video");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
