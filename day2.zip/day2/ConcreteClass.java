package week3.day2;

public class ConcreteClass extends SamsungTV{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ConcreteClass objSams = new ConcreteClass();
		objSams.prize();
		objSams.gamePlay();
		objSams.musicPlay();
		objSams.musicPlay();
		

	}

}
