package week3.day2;

public class CalculatorProgram {

	public void add(int num1,int num2)
	{
		
		int res1=num1 + num2;
		System.out.println(res1);
		
		
	}
	public void add (int num1,int num2,int num3)
	{
		
		int res2 = num1+ num2+ num3;
		System.out.println(res2);
		
	}
	 public void subtract (int num1, int num2)
	 {
		 
		 float res3 = num1 + num2;
		 System.out.println(res3);
		 
		 
		 
	 }
	public void subtract(double num1,double num2)
	
	{
       double res4 = num1+ num2;
       System.out.println(res4);
		
	}
	
	public void multiply(int num1,int num2)
	{
		int res5 = num1 * num2;
		System.out.println(res5);
	}
	
	public void multiply(int num1, double num2)
	{
		double res6 = num1 *num2;
		System.out.println(res6);
		
	}
	public void divide (int num1,int num2)
	{
		int res7 = num1/num2;
		System.out.println(res7);
	}
	
	public void divide( int num1, double num2)
	{
		double res8 =num1/num2;
		System.out.println(res8);
	}
	
	
	
	
	public static void main(String[] args) {
	
		CalculatorProgram objCalculate =new CalculatorProgram();
		
		objCalculate.add(2, 3);
		objCalculate.add(2, 3,5);
		objCalculate.multiply(2, 3);
		objCalculate.multiply(3, 12.55d);
		objCalculate.subtract(15, 7);
		objCalculate.subtract(19.5d, 12.5d);
	    objCalculate.divide(15, 3);
	    objCalculate.divide(20, 5.0d);
		

	}

}
