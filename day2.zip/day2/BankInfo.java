package week3.day2;

public class BankInfo {
	
	public void saving()
	{
		System.out.println("Savings account of bank");
	}
	public void fixed()
	{
		System.out.println("Fixed account of bank");
	}

	public void deposit()
	{
		System.out.println("Deposit account of bank");
	}
	public static void main(String[] args) {


	}

}
