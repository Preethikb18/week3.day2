package week3.day2;

public class Mobile {
	public void sendMsg()
	{
		
		System.out.println("Send Message");
	}
	
	public void makeCall()
	{
		System.out.println("MAke a call");
	}

	public void saveContact()
	{
		
		System.out.println("Save the contact");
	}
	public static void main(String[] args) {
		

	}

}
