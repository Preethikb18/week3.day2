package week3.day2;

public class AxisBank extends BankInfo{
	
	public void deposit()
	{
		System.out.println("Deposit account of Axis bank");
	}

	public static void main(String[] args) 
	
	{
		AxisBank objAxisBank = new AxisBank();
		objAxisBank.deposit();
		
		

	}

}
