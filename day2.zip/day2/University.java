package week3.day2;

public abstract class University {
	public void pg()
	{
		System.out.println("mplemented method");
	}
	public abstract void ug();

}
